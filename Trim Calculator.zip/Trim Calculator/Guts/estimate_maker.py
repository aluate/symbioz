import os
import pandas as pd
from datetime import datetime

# === Constants ===
BASE_DIR = "Z:/Trim Calculator"
TAKE_OFF_DIR = os.path.join(BASE_DIR, "Take Offs")
ESTIMATE_OUTPUT_DIR = os.path.join(BASE_DIR, "Estimates")
FINISH_RATES_FILE = os.path.join(BASE_DIR, "Guts", "Finish Rates.xlsx")
KNIFE_COST_FILE = os.path.join(BASE_DIR, "Guts", "knife costs.xlsx")
MARKUP_PERCENT = 0.3
LF_ADD_RATE = 0.85
SETUP_FEE = 70.0
MARGIN_PERCENT = 0.10

# === Helpers ===
def get_finish_category(width):
    if width <= 3.5:
        return 'Small'
    elif width <= 5:
        return 'Avg'
    else:
        return 'Large'

def load_finish_rates():
    df_rates = pd.read_excel(FINISH_RATES_FILE)
    df_rates.columns = df_rates.columns.str.strip().str.lower()
    rate_map = {}
    for _, row in df_rates.iterrows():
        finish = row.get('finish', '').strip()
        rate = row.get('rate', 0.0)
        if finish:
            rate_map[finish] = rate
    return rate_map

def fmt_dollars(val):
    return f"${val:,.2f}"

def load_knife_grind_rates():
    df_knife = pd.read_excel(KNIFE_COST_FILE)
    df_knife.columns = df_knife.columns.str.strip().str.lower()
    knife_rate_map = {}
    for _, row in df_knife.iterrows():
        profile = row.get('profile', '').strip().lower()
        rate = row.get('rate', 0.0)  # Expecting a per-inch rate
        if profile:
            knife_rate_map[profile] = rate
    print("\nDEBUG: Knife Rate Map Loaded:")
    print(knife_rate_map)
    print(df_knife[['profile', 'rate']])
    return knife_rate_map

def get_next_estimate_filename(directory, base_filename):
    name_part = os.path.basename(base_filename).replace("Take_Off", "Estimate").replace(".csv", "")
    existing_files = [f for f in os.listdir(directory) if f.startswith(name_part)]
    suffixes = [int(f.replace(name_part, "").replace("_", "").replace(".csv", "")) 
                for f in existing_files if f.replace(name_part, "").replace("_", "").replace(".csv", "").isdigit()]
    next_suffix = max(suffixes, default=0) + 1
    new_filename = f"{name_part}_{next_suffix}.csv"
    return os.path.join(directory, new_filename)

def get_finish_label(finish, species):
        finish = str(finish).strip().lower()
        species = str(species).strip().lower()
        if finish != 'yes':
            return "Unfinished"
        elif "poplar" in species:
            return "Primed"
        else:
            return "Stained"

def prepare_printable_estimate(df):
    # Create 'Description'
    df['Description'] = df.apply(
        lambda row: f"{get_finish_label(row['finish'], row['species'])} "
                    f"{row['species']} {row['part']} {row['width']:.2f}\" x {row['thickness']:.2f}\"",
        axis=1
    )

    # Create printable DataFrame with renamed columns and rounded values
    printable_df = pd.DataFrame({
        "Qty LF": df['lf'].round(2),
        "Description": df['Description'],
        "LF Price": df['cost/lf'].round(2),
        "Set Up": df['knife grind'].round(2),
        "Finish": df['finish rate'].round(2),
        "LF Price Line Total": df['base total'].round(2)
    })

    return printable_df

# === Estimate Logic ===
def calculate_estimate(file_path, apply_finish='yes', markup_pct=0.3, lf_add_rate=0.85, margin_pct=0.10):
    import streamlit as st

    st.write("🛠 Received Inputs:")
    st.write(f"Apply Finish: {apply_finish}")
    st.write(f"Markup %: {markup_pct}")
    st.write(f"LF Add Rate: {lf_add_rate}")
    st.write(f"Margin %: {margin_pct}")
    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip().str.lower()

    if 'bf' not in df.columns or 'bf price' not in df.columns:
        raise KeyError("CSV must contain 'BF' and 'BF Price' columns.")

    if 'profile' not in df.columns:
        raise KeyError("Takeoff is missing required 'profile' column.")

    # Clean up profile column
    df['profile'] = df['profile'].astype(str).str.strip().str.lower()

    print("\nDEBUG: Profiles in takeoff:")
    print(df['profile'].unique())

    finish_rates = load_finish_rates()
    knife_rates = load_knife_grind_rates()

    df['material total'] = df['bf'] * df['bf price']

    df['finish type'] = df['species'].apply(lambda x: 'Primed' if 'poplar' in str(x).lower() else 'Stained')
    df['finish category'] = df['width'].apply(get_finish_category)
    df['finish key'] = df['finish type'] + ' ' + df['finish category']

    df['finish'] = apply_finish
    df['finish rate'] = df['finish key'].map(finish_rates).fillna(0.0)
    df['finish rate'] = df.apply(lambda row: row['finish rate'] if str(row['finish']).lower() == 'yes' else 0.0, axis=1)
    df['finish total'] = df['lf'] * df['finish rate']

    df['lf add'] = df['lf'] * lf_add_rate if 'lf' in df.columns else 0
    df['markup'] = (df['material total'] + df['finish total'] + df['lf add']) * markup_pct
    # Step 1: Calculate subtotal before margin
    df['pre_margin_total'] = df['material total'] + df['finish total'] + df['lf add']

# Step 2: Margin
    df['margin'] = df['pre_margin_total'] * margin_pct

# Step 3: Total cost (before setup fee)
    df['total cost'] = df['pre_margin_total'] + df['margin']

# Step 4: Add knife grind cost
    df['knife rate'] = df['profile'].map(knife_rates).fillna(0.0)
    df['knife grind'] = df['width'] * df['knife rate']
    df['total cost'] += df['knife grind']

# Step 5: Separate base cost (excluding finish)
    df['base total'] = df['total cost'] - df.get('finish total', 0)

# Step 6: Cost per LF excluding finish
    df['cost/lf'] = df.apply(lambda row: row['base total'] / row['lf'] if row['lf'] > 0 else 0.0, axis=1)
    df['margin'] = df['pre_margin_total'] * MARGIN_PERCENT
    df['total cost'] = df['pre_margin_total'] + df['margin']
# === Add Description Column ===
    def format_dimension(w, t):
        return f"{w:.2f}\" x {t:.2f}\""

    df['description'] = df.apply(
        lambda row: f"{get_finish_label(row['finish'], row['species'])} "
                    f"{row['species']} {row['part']} "
                    f"{format_dimension(row['width'], row['thickness'])}",
        axis=1
)

    df['knife rate'] = df['profile'].map(knife_rates).fillna(0.0)
    print("\nDEBUG: Knife rates applied to profiles:")
    print(df[['profile', 'knife rate']].drop_duplicates())

    df['knife grind'] = df['width'] * df['knife rate']
    df['total cost'] += df['knife grind']
    # Add cost per LF calculation
    df['cost/lf'] = df.apply(lambda row: row['total cost'] / row['lf'] if row['lf'] > 0 else 0.0, axis=1)
    total_estimate = df['total cost'].sum() + SETUP_FEE
    # Step 1: Separate finish from base cost
    df['base total'] = df['total cost'] - df.get('finish total', 0)

    # Step 2: Add cost per LF excluding finish
    df['cost/lf'] = df.apply(lambda row: row['base total'] / row['lf'] if row['lf'] > 0 else 0.0, axis=1)
    estimate_path = get_next_estimate_filename(ESTIMATE_OUTPUT_DIR, file_path)
    df.to_csv(estimate_path, index=False)

    # === PDF Export ===
    printable_df = prepare_printable_estimate(df)
    pdf_path = estimate_path.replace(".csv", ".pdf")
    export_pdf_from_dataframe(printable_df, pdf_path)
    print(f"PDF version saved to: {pdf_path}")

    return estimate_path, total_estimate, df.columns.tolist(), printable_df, pdf_path


def fmt_dollars(val):
    return f"${val:,.2f}"

def run_estimate_for_file(file_path, apply_finish='yes', markup_pct=0.3, lf_add_rate=0.85, margin_pct=0.10):
    estimate_path, total_estimate, columns, df = calculate_estimate(
        file_path,
        apply_finish=apply_finish,
        markup_pct=markup_pct,
        lf_add_rate=lf_add_rate,
        margin_pct=margin_pct
    )

    printable_df = pd.DataFrame({
        "Qty LF": df['lf'].round(2),
        "Description": df['description'],
        "LF Price": df['cost/lf'].apply(fmt_dollars),
        "Set Up": df['knife grind'].apply(fmt_dollars),
        "Finish": df['finish total'].apply(fmt_dollars),
        "LF Price Line Total": df['base total'].apply(fmt_dollars)
    })

    pdf_path = estimate_path.replace(".csv", ".pdf")
    export_pdf_from_dataframe(printable_df, pdf_path)

    return estimate_path, total_estimate, df.columns.tolist(), printable_df, pdf_path

from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib.pagesizes import LETTER
from reportlab.lib import colors

def export_pdf_from_dataframe(df, output_path):
    from reportlab.lib.units import inch

    pdf = SimpleDocTemplate(output_path, pagesize=LETTER)
    elements = []

    # Table header
    data = [df.columns.tolist()] + df.values.tolist()

    # Format table
    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.lightgrey),
        ('GRID', (0,0), (-1,-1), 0.5, colors.black),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('FONTSIZE', (0,0), (-1,-1), 9),
        ('BOTTOMPADDING', (0,0), (-1,0), 6),
    ]))

    elements.append(table)
    pdf.build(elements)

# === CLI Support ===
def main():
    files = [f for f in os.listdir(TAKE_OFF_DIR) if f.endswith('.csv')]
    if not files:
        print("No takeoff files found.")
        return

    print("Available Takeoff Files:")
    for idx, f in enumerate(files):
        print(f"{idx+1}: {f}")

    choice = int(input("Select a file by number: ")) - 1
    selected_file = files[choice]
    selected_path = os.path.join(TAKE_OFF_DIR, selected_file)

    estimate_path, total, columns, df = calculate_estimate(selected_path)

    print("\nGenerated Estimate:")
    print(df[['profile', 'lf', 'width', 'thickness']].head())
    print(f"\nTOTAL ESTIMATE (with Setup & Knife Grind): ${total:,.2f}")
    print(f"\nSaved to: {estimate_path}")

if __name__ == "__main__":
    main()
