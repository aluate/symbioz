import pandas as pd
import math
from datetime import datetime
import os
import streamlit as st
from estimator import estimate_trim_cost, write_results_to_csv
BASE_DIR = "Z:/Trim Calculator/Guts"



# === Constants ===
THICKNESS_OPTIONS = {
    '1': '4/4',
    '1.25': '5/4',
    '1.5': '6/4',
    '2': '8/4'
}

DEFAULT_EXTRA_BF_PERCENT = 0.15
CSV_OUTPUT_DIR = "./"

# === Load external files ===
BASE_DIR = "Z:/Trim Calculator/Guts"

TRIM_SIZES_PATH = os.path.join(BASE_DIR, "trim_dimensions.xlsx")
BF_PRICING_PATH = os.path.join(BASE_DIR, "bf pricing.xlsx")
AWI_WASTE_CHART_PATH = os.path.join(BASE_DIR, "awi_waste_chart.xlsx")
LUMBER_PRICES_PATH = BF_PRICING_PATH  # If you're using bf pricing as your lumber price file
CSV_OUTPUT_DIR = BASE_DIR

@st.cache_data
def load_trim_dimensions(path):
    df = pd.read_excel(path)
    df.columns = df.columns.str.strip().str.upper()
    return df

@st.cache_data
def load_bf_price_reference(path):
    df = pd.read_excel(path, sheet_name=0)
    df.columns = df.columns.str.strip().str.lower()
    return df

@st.cache_data
def load_waste_factors(path):
    df = pd.read_excel(path, index_col=0)
    # Clean up index
    df.index = df.index.map(lambda x: round(float(x), 3))
    # Only keep numeric columns (e.g., 1.0, 1.25)
    df = df[[col for col in df.columns if '/' not in str(col)]]
    df.columns = [float(col) for col in df.columns]
    return df

trim_df = load_trim_dimensions(TRIM_SIZES_PATH)
bf_price_df = load_bf_price_reference(BF_PRICING_PATH)
awi_df = load_waste_factors(AWI_WASTE_CHART_PATH)

# === Streamlit UI ===
st.title("Trim Estimator")

# Job and Customer
job_name = st.text_input("Job Name")
customer_name = st.text_input("Customer Name")

# Numeric inputs for takeoff
ext_wall = st.number_input("Exterior Wall (LF)", min_value=0)
int_wall = st.number_input("Interior Wall (LF)", min_value=0)
ext_doors = st.number_input("Exterior Doors", min_value=0)
sliders = st.number_input("Sliders", min_value=0)
windows = st.number_input("Windows", min_value=0)
int_doors = st.number_input("Interior Doors", min_value=0)
pocket_doors = st.number_input("Pocket Doors", min_value=0)
barn_doors = st.number_input("Barn/Wrapped Openings", min_value=0)

# Door Height restricted to known values
door_height = st.selectbox("Door Height", [80, 84, 96])

# Restrict style choices to known values from trim sheet
style_options = sorted(trim_df['STYLE'].dropna().unique())
style = st.selectbox("Select Style", style_options)


# Restrict Profile to known values
profile_options = ["", "E2E", "Custom", "Book"]
profile = st.selectbox("Select Profile", profile_options)


# Finish size option
finish_size = st.selectbox("Finish Size", ["Standard", "Economy", "Upgrade"])

# Drywall Int Jambs and Wrap options (yes/no)
drywall_int_jambs = st.selectbox("Drywall Interior Jambs", ["yes", "no"])
drywall_wrap = st.selectbox("Drywall Wrap", ["yes", "no"])

# Species 1–3 selection from known list in BF pricing
species_options = [""] + sorted(bf_price_df['ui name'].dropna().astype(str).str.strip().unique())
species1 = st.selectbox("Species 1", species_options)
species2 = st.selectbox("Species 2", species_options)
species3 = st.selectbox("Species 3", species_options)

if st.button("Generate Takeoff"):
    from estimator import estimate_trim_cost, write_results_to_csv
    from estimate_maker import run_estimate_for_file

    # Collect inputs into a dict
    inputs = {
        "job": job_name,
        "customer": customer_name,
        "style": style,
        "extWall": ext_wall,
        "intWall": int_wall,
        "extDoors": ext_doors,
        "sliders": sliders,
        "windows": windows,
        "intDoors": int_doors,
        "pocketDoors": pocket_doors,
        "barnDoors": barn_doors,
        "doorHeight": door_height,
        "drywallIntJambs": drywall_int_jambs.lower(),
        "drywallWrap": drywall_wrap.lower(),
        "species1": species1.lower(),
        "species2": species2.lower(),
        "species3": species3.lower(),
        "finishSize": finish_size.lower(),
        "profile": profile.lower()
    }

    try:
        results_df = estimate_trim_cost(inputs)
        output_path = write_results_to_csv(results_df, inputs)

        estimate_path, total, columns, preview = run_estimate_for_file(output_path)

        if estimate_path:
            st.success("Estimate generated successfully!")
            st.write(f"Total Estimate (with Setup & Knife Grind): **${total:,.2f}**")
            st.write("Preview of Estimate:")
            columns_to_display = ['species', 'part', 'lf', 'width', 'thickness']
            if preview is not None and not preview.empty:
                filtered_preview = preview[columns_to_display]
            else:
                filtered_preview = pd.DataFrame(columns=columns_to_display)

            with open(estimate_path, "rb") as ef:
                st.download_button("Download Estimate CSV", ef, file_name=os.path.basename(estimate_path))
        else:
            st.warning("Estimate generation failed.")

    except Exception as e:
        st.error(f"Error generating estimate: {e}")