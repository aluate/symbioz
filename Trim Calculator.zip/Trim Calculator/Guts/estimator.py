import pandas as pd
import math
from datetime import datetime
import os
BASE_DIR = "Z:/Trim Calculator/Guts"


# === Constants ===
THICKNESS_OPTIONS = {
    '1': '4/4',
    '1.0': '4/4',
    '1.25': '5/4',
    '1.3': '5/4',
    '1.5': '6/4',
    '1.50': '6/4',
    '2': '8/4',
    '2.0': '8/4'
}
DEFAULT_EXTRA_BF_PERCENT = 0.15
CSV_OUTPUT_DIR = "./"

# === Load external files ===
TRIM_SIZES_PATH = os.path.join(BASE_DIR, "trim_dimensions.xlsx")
BF_PRICING_PATH = os.path.join(BASE_DIR, "bf pricing.xlsx")
AWI_WASTE_CHART_PATH = os.path.join(BASE_DIR, "awi_waste_chart.xlsx")
LUMBER_PRICES_PATH = BF_PRICING_PATH  # If you're using bf pricing as your lumber price file
CSV_OUTPUT_DIR = "Z:/Trim Calculator/Take Offs"

def load_trim_dimensions(path):
    df = pd.read_excel(path)
    df.columns = df.columns.str.strip().str.upper()
    return df


# === Load Excel Reference Data ===
trim_df = pd.read_excel(TRIM_SIZES_PATH)

def load_lumber_prices(path):
    df = pd.read_excel(path)
    df.columns = df.columns.str.strip().str.title()
    # Normalize possible column names
    for col in df.columns:
        if "Price" in col and "Bf" in col:
            df = df.rename(columns={col: 'BF Price'})
            break
    return df
lumber_price_df = load_lumber_prices(LUMBER_PRICES_PATH)
  
def load_waste_factors(path):
    return pd.read_excel(path, index_col=0)


awi_df = load_waste_factors(AWI_WASTE_CHART_PATH)

# === Helper Functions ===

def get_bf_price_from_reference(thickness, species):
    df = pd.read_excel(BF_REFERENCE_PATH, sheet_name=0)
    df.columns = df.columns.str.strip().str.lower()

    thickness_values = sorted([float(k) for k in THICKNESS_OPTIONS.keys()])
    rounded_thickness = next((t for t in thickness_values if thickness <= t), thickness_values[-1])

    # Match both thickness and species
    matches = df[
        (df['thickness'] == rounded_thickness) &
        (df['name'].str.lower() == species.lower())
    ]

    if not matches.empty:
        return matches.iloc[0]['bf price']
    return 0.0

def round_up_inches_to_feet(inches):
    return math.ceil(inches / 12)

def get_actual_dimensions(row, size_selection, custom_sizes=None):
    part = row['PART'].lower()
    if custom_sizes and part in custom_sizes:
        return custom_sizes[part]['width'], custom_sizes[part]['thickness']

    if size_selection.lower() == 'economy':
        return row['ECONOMY WIDTH'], row['ECONOMY THICKNESS']
    elif size_selection.lower() == 'upgraded':
        return row['UPGRADE WIDTH'], row['UPGRADED THICKNESS']
    else:
        return row['STANDARD WIDTH'], row['STANDARD THICKNESS']

def get_waste_factor(width, thickness):
    # Round up to the next standard size (e.g., 1.125" -> 1.25")
    standard_sizes = sorted([float(k) for k in THICKNESS_OPTIONS.keys()])
    rounded_thickness = next((s for s in standard_sizes if thickness <= s), standard_sizes[-1])

    # Convert thickness to string key format used in AWI (e.g., '1.25')
    rounded_str = f"{float(rounded_thickness):.2f}".rstrip('0').rstrip('.')

    try:
        thickness_label = THICKNESS_OPTIONS[rounded_str]
    except KeyError:
        raise KeyError(f"Unsupported thickness after rounding: {rounded_str}")

    try:
        return awi_df.loc[min(round(width, 3), 9.0), thickness_label]
    except KeyError:
        raise KeyError(f"AWI waste factor not found for width {width} and thickness {thickness_label}")


reference_path = BF_PRICING_PATH

def get_bf_price_from_reference(thickness, species_name):
    import pandas as pd

    reference_path = BF_PRICING_PATH
    df = pd.read_excel(reference_path, sheet_name=0)
    df.columns = df.columns.str.strip().str.lower()

    name_col = next((col for col in df.columns if 'name' in col), None)
    price_col = next((col for col in df.columns if 'price' in col), None)

    if not name_col or not price_col:
        raise ValueError("Missing required columns in BF pricing reference.")

    # Normalize thickness
    thickness_values = sorted([float(k) for k in THICKNESS_OPTIONS.keys()])
    rounded_thickness = next((t for t in thickness_values if thickness <= t), thickness_values[-1])
    thickness_label = THICKNESS_OPTIONS.get(str(rounded_thickness), None)
    if not thickness_label:
        raise KeyError(f"Unsupported thickness: {rounded_thickness}")

    species_tokens = species_name.lower().split()
    df['name_normalized'] = df[name_col].astype(str).str.strip().str.lower()

    # Match all species tokens and thickness_label
    def matches(row):
        return all(token in row for token in species_tokens) and thickness_label in row

    match_row = df[df['name_normalized'].apply(matches)]
    if not match_row.empty:
        return match_row.iloc[0][price_col]

    print(f"WARNING: No BF price found for species '{species_name}' at '{thickness_label}' in price sheet.")
    return 0.0
def calculate_bf(lf, width, thickness, extra_percent=DEFAULT_EXTRA_BF_PERCENT):
    waste_factor = get_waste_factor(width, thickness)
    raw_bf = lf * waste_factor
    return raw_bf * (1 + extra_percent)

def build_part_counts(inputs):
    door_legs = round_up_inches_to_feet(inputs['doorHeight'])
    double_leg_count = lambda n: n * 2 * door_legs
    single_leg_count = lambda n: n * door_legs

    has_drywall_jambs = inputs['drywallIntJambs'].lower() == 'yes'

    return {
        'base': inputs['extWall'] + inputs['intWall'] * 2,
        'case': (
            double_leg_count(inputs['intDoors']) +
            (0 if has_drywall_jambs else (double_leg_count(inputs['pocketDoors']) + double_leg_count(inputs['barnDoors']))) +
            single_leg_count(inputs['extDoors'] + inputs['windows'] + inputs['sliders'])
        ),
        'header': (
            (inputs['intDoors'] + (0 if has_drywall_jambs else (inputs['pocketDoors'] + inputs['barnDoors']))) * door_legs / 2
        ) + (0 if has_drywall_jambs else (inputs['windows'] + inputs['extDoors'] + inputs['sliders']) * door_legs / 2),
        'int jamb': 0 if has_drywall_jambs else (inputs['pocketDoors'] + inputs['barnDoors']) * door_legs,
        'window jamb': 0 if inputs['drywallWrap'].lower() == 'yes' else ((inputs['windows'] * 2 + inputs['extDoors'] * 3 + inputs['sliders'] * 3) * door_legs),
        'sill': 0 if inputs['style'].lower() == 'mitered' else inputs['windows'] * door_legs,
        'apron': 0 if inputs['style'].lower() == 'mitered' else inputs['windows'] * door_legs,
        'dentil': 0 if inputs['style'].lower() != 'craftsman plus' else 2 * (
            (inputs['intDoors'] + (0 if has_drywall_jambs else (inputs['pocketDoors'] + inputs['barnDoors']))) * door_legs / 2
        )
    }

def estimate_trim_cost(inputs, overrides={}):
    style = inputs['style']
    size_selection = inputs['finishSize']
    part_counts = build_part_counts(inputs)
    door_height = inputs['doorHeight']
    species_inputs = [inputs.get('species1'), inputs.get('species2'), inputs.get('species3')]
    toggles = {'drywallIntJambs': inputs['drywallIntJambs'], 'drywallWrap': inputs['drywallWrap']}

    results = []
    leg_height = round_up_inches_to_feet(door_height)

    for species in species_inputs:
        if not species:
            continue

        for _, row in trim_df.iterrows():
            if row['STYLE'].lower() != style.lower():
                continue

            part = row['PART'].lower()
            lf = part_counts.get(part, 0)
            custom_price = overrides.get(part)
            actual_width, actual_thickness = get_actual_dimensions(row, size_selection)

            if pd.isna(actual_width) or pd.isna(actual_thickness):
                continue

            bf = calculate_bf(lf, float(actual_width), float(actual_thickness))
            bf_price = custom_price if custom_price else get_bf_price_from_reference(
                float(actual_thickness),
                species
            )
            material_cost = bf * bf_price

            results.append({
                'style': style,
                'species': species,
                'part': part,
                'lf': lf,
                'width': actual_width,
                'thickness': actual_thickness,
                'bf': round(bf, 2),
                'bf price': round(bf_price, 2),
                'material cost': round(material_cost, 2),
                'profile': inputs.get('profile', '')
            })
    return results

def write_results_to_csv(results, inputs):
    today_str = datetime.today().strftime('%Y-%m-%d')
    job = inputs.get('job', 'Unknown').replace(" ", "_")
    customer = inputs.get('customer', 'Unknown').replace(" ", "_")
    base_filename = os.path.join(CSV_OUTPUT_DIR, f"{today_str}_{job}_{customer}_Take_Off")
    counter = 1
    filename = f"{base_filename}.csv"

    # If file already exists, add a counter to create a unique name
    while os.path.exists(filename):
        filename = f"{base_filename}_{counter}.csv"
        counter += 1

    df = pd.DataFrame(results)
    df.to_csv(filename, index=False)
    return filename

if __name__ == "__main__":
    sample_inputs = {
        'job': 'GREENE',
        'customer': 'BAR 17',
        'extWall': 150,
        'intWall': 100,
        'extDoors': 3,
        'sliders': 3,
        'windows': 15,
        'intDoors': 15,
        'pocketDoors': 2,
        'barnDoors': 1,
        'doorHeight': 80,
        'style': 'craftsman plus',
        'profile': 'e2e',
        'drywallIntJambs': 'yes',
        'drywallWrap': 'yes',
        'species1': 'Poplar',
        'species2': 'knotty alder',
        'species3': 'rift white oak sorted 6+',
        'finishSize': 'upgrade'
    }

    results = estimate_trim_cost(sample_inputs)
    file_path = write_results_to_csv(results, sample_inputs)
    print(f"Test complete. CSV written to: {file_path}")

