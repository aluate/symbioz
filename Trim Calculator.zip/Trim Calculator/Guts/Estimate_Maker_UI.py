import os
import pandas as pd
import streamlit as st
from estimate_maker import run_estimate_for_file

# === Constants ===
BASE_DIR = "Z:/Trim Calculator"
TAKE_OFF_DIR = os.path.join(BASE_DIR, "Take Offs")

# === Streamlit Config ===
st.set_page_config(page_title="Trim Estimate Generator", layout="centered")
st.title("📊 Trim Estimate Generator")

# === Sidebar Inputs ===
st.sidebar.header("🛠 Overrides")
apply_finish_toggle = st.sidebar.selectbox("Apply Finish?", ["Yes", "No"])
markup_pct = st.sidebar.number_input("Markup %", value=0.3, step=0.01, format="%.2f")
lf_add_rate = st.sidebar.number_input("LF Add Rate", value=0.85, step=0.01)
margin_pct = st.sidebar.number_input("Margin %", value=0.10, step=0.01, format="%.2f")

# === File Selector ===
files = [f for f in os.listdir(TAKE_OFF_DIR) if f.endswith(".csv")]
file_choice = st.selectbox("Select a Takeoff File", files)

# === Run Estimate ===
if st.button("Generate Estimate"):
    if not file_choice:
        st.error("No file selected.")
    else:
        selected_path = os.path.join(TAKE_OFF_DIR, file_choice)

        try:
            estimate_path, total, columns, printable_df, pdf_path = run_estimate_for_file(
                selected_path,
                apply_finish=apply_finish_toggle,
                markup_pct=markup_pct,
                lf_add_rate=lf_add_rate,
                margin_pct=margin_pct
            )


            st.success("Estimate generated successfully!")
            st.write(f"Total Estimate (with Setup & Knife Grind): **${total:,.2f}**")

            st.dataframe(printable_df)

            with open(estimate_path, "rb") as ef:
                st.download_button("Download Estimate CSV", ef, file_name=os.path.basename(estimate_path))

            with open(pdf_path, "rb") as pf:
                st.download_button("Download Estimate PDF", pf, file_name=os.path.basename(pdf_path))


        except Exception as e:
            st.error(f"Error generating estimate: {e}")
