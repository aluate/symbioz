# Residential SOP Notes

Notes tying PDF binder to automations.

