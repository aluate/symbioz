# Residential Ops – Big Dumb Running Notes

This file is allowed to be messy.

This file is NOT a source of truth for file structure.

This file should NOT be used to "infer" folder layouts or rename things.

From now on, if you need a scratchpad for ideas or TODOs, prefer THIS file.

