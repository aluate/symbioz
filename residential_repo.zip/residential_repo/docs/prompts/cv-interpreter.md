# CV Interpreter Prompt

