# Spec sheet model

