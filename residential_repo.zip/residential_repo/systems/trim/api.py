"""
Trim system module: API for a phone-friendly trim calculator.
"""
# TODO: implement this later.

