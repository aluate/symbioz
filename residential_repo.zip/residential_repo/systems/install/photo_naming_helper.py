# Photo naming helper

