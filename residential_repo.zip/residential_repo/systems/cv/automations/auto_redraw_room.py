# Auto redraw room

