# Auto cabinet placement

