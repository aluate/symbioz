# Geometry normalization

