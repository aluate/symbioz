# Geometry inference

